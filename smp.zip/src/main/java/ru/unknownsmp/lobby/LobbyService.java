package ru.unknownsmp.lobby;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Difficulty;
import org.bukkit.GameMode;
import org.bukkit.GameRule;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.block.Block;
import org.bukkit.block.data.Orientable;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.EntityPortalEnterEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerPortalEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.persistence.PersistentDataType;
import ru.unknownsmp.core.Module;
import ru.unknownsmp.core.Msg;
import ru.unknownsmp.core.Keys;
import ru.unknownsmp.core.Tasks;
import ru.unknownsmp.core.Text;
import ru.unknownsmp.core.UnknownSMP;
import ru.unknownsmp.profile.Profile;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Лобби: отдельный пустой мир с платформой, порталом в выживание, правилами, паркуром и секретами.
 * Неавторизованные игроки находятся в изолированной камере лобби.
 */
public final class LobbyService implements Module, Listener {
    private static final int BUILD_VERSION = 2;
    /** Секретные кнопки лобби (пасхалки). */
    public static final Map<String, int[]> SECRETS = Map.of(
            "lobby_portal_top", new int[]{0, 109, -15},
            "lobby_under", new int[]{5, 96, 4},
            "lobby_parkour_end", new int[]{60, 112, 3}
    );

    private final UnknownSMP plugin;
    private World world;
    private ParkourService parkour;
    private CosmeticsService cosmetics;
    private final Map<UUID, Long> portalCooldown = new ConcurrentHashMap<>();
    private final Set<UUID> entering = ConcurrentHashMap.newKeySet();

    public LobbyService(UnknownSMP plugin) {
        this.plugin = plugin;
    }

    @Override public String id() { return "lobby"; }
    @Override public String title() { return "Лобби"; }
    @Override public String[] depends() { return new String[]{"profiles", "state"}; }

    @Override
    public void enable() {
        String name = plugin.lobbyWorldName();
        world = Bukkit.getWorld(name);
        if (world == null) {
            world = new WorldCreator(name).generator(new VoidGenerator())
                    .generateStructures(false).environment(World.Environment.NORMAL).createWorld();
        }
        if (world == null) throw new IllegalStateException("Не удалось создать мир лобби " + name);
        world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
        world.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
        world.setGameRule(GameRule.DO_MOB_SPAWNING, false);
        world.setGameRule(GameRule.KEEP_INVENTORY, true);
        world.setGameRule(GameRule.DO_FIRE_TICK, false);
        world.setGameRule(GameRule.ANNOUNCE_ADVANCEMENTS, false);
        world.setDifficulty(Difficulty.PEACEFUL);
        world.setTime(6000);
        world.setStorm(false);
        world.setSpawnLocation(0, 101, 0);
        for (int x = -3; x <= 4; x++) for (int z = -2; z <= 2; z++) world.addPluginChunkTicket(x, z, plugin);
        world.addPluginChunkTicket(1000 >> 4, 1000 >> 4, plugin);
        if (plugin.state().getLong("lobby_built", 0) < BUILD_VERSION) {
            LobbyBuilder.build(world);
            plugin.state().set("lobby_built", BUILD_VERSION);
            plugin.getLogger().info("Лобби построено в мире " + name);
        }
        spawnHolograms();
        Bukkit.getPluginManager().registerEvents(this, plugin);
        parkour = new ParkourService(plugin, this);
        Bukkit.getPluginManager().registerEvents(parkour, plugin);
        cosmetics = new CosmeticsService(plugin);
        cosmetics.start();
        plugin.auth().onJoin(this::onPreAuthJoin);
        plugin.auth().onLogin(this::afterLogin);
        registerCommands();
    }

    public World world() { return world; }

    public ParkourService parkour() { return parkour; }

    public CosmeticsService cosmetics() { return cosmetics; }

    public boolean isLobby(World w) { return w != null && world != null && w.equals(world); }

    public Location spawn() {
        Location l = Text.loc(plugin.configs().main().getString("lobby.spawn", ""));
        return l != null ? l : new Location(world, 0.5, 101, 0.5, 180, 0);
    }

    public void setSpawn(Location l) {
        plugin.configs().main().set("lobby.spawn", Text.loc(l));
        plugin.configs().save("config.yml");
    }

    public Location authSpot() {
        return world == null ? null : new Location(world, 1000.5, 150, 1000.5, 0, 0);
    }

    // ------------------------------------------------------------------ Переходы

    private void onPreAuthJoin(Player p) {
        // Новичок появляется на ванильной точке мира — её не запоминаем, чтобы первый вход был на площади спавна.
        if (p.hasPlayedBefore()) rememberSurvival(p, p.getLocation());
    }

    /** Запомнить позицию выживания, если игрок сейчас не в лобби. */
    public void rememberSurvival(Player p, Location l) {
        if (l == null || isLobby(l.getWorld()) || (plugin.duels() != null && plugin.duels().isDuelWorld(l.getWorld()))) return;
        Profile pr = plugin.profiles().get(p);
        if (pr == null) return;
        pr.lastLoc = Text.loc(l);
        pr.dirty = true;
    }

    private void afterLogin(Player p) {
        Profile pr = plugin.profiles().get(p);
        boolean useLobby = plugin.configs().main().getBoolean("lobby.enabled", true);
        if (useLobby && !plugin.configs().main().getBoolean("lobby.skip-after-login", false)) {
            toLobby(p);
            Msg.title(p, Msg.t("lobby.title", "&5&lUNKNOWN SMP"), Msg.t("lobby.subtitle", "&7Войдите в портал или нажмите на &fПроводника"), 10, 70, 20);
            if (pr != null && pr.lastLoc == null) {
                Msg.send(p, "lobby.first", "&fДобро пожаловать! Здесь можно прочитать правила, пройти паркур и найти секреты. Портал ведёт в выживание. Меню сервера: &e/menu");
            }
        } else {
            enterSurvival(p);
        }
    }

    public void toLobby(Player p) {
        if (!isLobby(p.getWorld())) rememberSurvival(p, p.getLocation());
        if (p.getGameMode() == GameMode.SURVIVAL) p.setGameMode(GameMode.ADVENTURE);
        p.teleportAsync(spawn(), PlayerTeleportEvent.TeleportCause.PLUGIN);
        p.setFoodLevel(20);
        p.setFireTicks(0);
    }

    /** Вход в выживание: последняя позиция или общий спавн при первом входе. */
    public void enterSurvival(Player p) {
        if (!entering.add(p.getUniqueId())) return;
        Profile pr = plugin.profiles().get(p);
        Location target = pr == null ? null : Text.loc(pr.lastLoc);
        boolean first = target == null;
        if (target == null || isLobby(target.getWorld()) || (plugin.duels() != null && plugin.duels().isDuelWorld(target.getWorld()))) target = plugin.world().spawn();
        if (plugin.dimensions() != null && !plugin.dimensions().canBeIn(target.getWorld())) target = plugin.world().spawn();
        if (p.getGameMode() == GameMode.ADVENTURE) p.setGameMode(GameMode.SURVIVAL);
        p.teleportAsync(target, PlayerTeleportEvent.TeleportCause.PLUGIN).whenComplete((ok, t) -> Tasks.sync(() -> {
            entering.remove(p.getUniqueId());
            if (!p.isOnline()) return;
            if (first) {
                Msg.title(p, Msg.t("lobby.welcome-title", "&5Мир UNKNOWN"), Msg.t("lobby.welcome-sub", "&7Выживайте. Доверяйте осторожно."), 10, 80, 20);
                Msg.send(p, "lobby.welcome", "&fВы на общем спавне. PvP разрешено везде, кроме зоны спавна. Приватов нет — берегите ценности. &e/menu&f — меню сервера.");
            }
        }));
    }

    private void registerCommands() {
        plugin.commands().add("lobby").player().perm("usmp.player.lobby").module("lobby").cat("Перемещение")
                .usage("/lobby").desc("Вернуться в лобби").exec((s, a) -> {
                    Player p = (Player) s;
                    if (plugin.combat() != null && plugin.combat().isTagged(p)) {
                        Msg.error(p, "combat.blocked", "Нельзя во время боя.");
                        return;
                    }
                    if (isLobby(p.getWorld())) { Msg.error(p, "lobby.already", "Вы уже в лобби."); return; }
                    plugin.teleports().teleportWithWarmup(p, spawn(), "лобби", () -> {
                        rememberSurvival(p, p.getLocation());
                        if (p.getGameMode() == GameMode.SURVIVAL) p.setGameMode(GameMode.ADVENTURE);
                    });
                });
        plugin.commands().add("play").player().perm("usmp.player.lobby").module("lobby").cat("Перемещение")
                .usage("/play").desc("Войти в выживание из лобби").exec((s, a) -> {
                    Player p = (Player) s;
                    if (!isLobby(p.getWorld())) { Msg.error(p, "lobby.not-in", "Вы уже в мире выживания."); return; }
                    enterSurvival(p);
                });
    }

    // ------------------------------------------------------------------ Голограммы

    private void spawnHolograms() {
        for (Entity e : world.getEntities()) {
            if (e.getPersistentDataContainer().has(Keys.LOBBY_ENTITY, PersistentDataType.BYTE)) e.remove();
        }
        List<String> rules = plugin.configs().main().getStringList("lobby.rules");
        if (rules.isEmpty()) rules = List.of("&5&lПРАВИЛА UNKNOWN SMP", "&7PvP разрешено везде, кроме спавна", "&7Приватов нет — грабить можно",
                "&7Выход из боя = потеря вещей и 10% денег", "&7Читы, дюпы и обход защиты запрещены", "&7Уважайте игроков в чате");
        holo(new Location(world, -6.5, 103.2, -6.5), String.join("\n", rules));
        holo(new Location(world, 0.5, 110.0, -14.5), "&d&lРЕЖИМ SMP\n&7Выживание, кланы, экономика\n&7Войдите в портал или /play");
        holo(new Location(world, 0.5, 110.0, 14.5), "&c&lРЕЖИМ ДУЭЛИ\n&7Честные бои 1 на 1 с наборами\n&7Ваши вещи SMP в безопасности\n&7Войдите в портал или /duels");
        holo(new Location(world, 18.5, 103.5, 0.5), "&e&lПАРКУР\n&7Встаньте на золотую плиту\n&7Лучшее время сохраняется");
        holo(new Location(world, 6.5, 103.2, -6.5), "&b&lПОДСКАЗКИ\n&7/menu — главное меню\n&7/help — все команды\n&7/shop /ah /sell — рынок\n&7/clan — кланы\n&7/quests — задания");
        holo(new Location(world, 1000.5, 152.6, 1004.2), "&5&lUNKNOWN SMP\n&fДобро пожаловать!\n\n&7Новый игрок: &e/register <пароль> <пароль>\n&7Уже играли: &e/login <пароль>\n\n&8На вход даётся 60 секунд");
    }

    private void holo(Location l, String text) {
        world.spawn(l, TextDisplay.class, td -> {
            td.text(Text.c(text));
            td.setBillboard(Display.Billboard.CENTER);
            td.setBackgroundColor(Color.fromARGB(120, 10, 0, 20));
            td.setShadowed(true);
            td.setPersistent(false);
            td.getPersistentDataContainer().set(Keys.LOBBY_ENTITY, PersistentDataType.BYTE, (byte) 1);
        });
    }

    // ------------------------------------------------------------------ Защита лобби

    private boolean staffBuild(Player p) {
        return p.getGameMode() == GameMode.CREATIVE && plugin.roles().has(p, "usmp.admin.build");
    }

    @EventHandler(priority = EventPriority.LOW)
    public void damage(EntityDamageEvent e) {
        if (!isLobby(e.getEntity().getWorld())) return;
        if (e.getEntity() instanceof Player p) {
            e.setCancelled(true);
            if (e.getCause() == EntityDamageEvent.DamageCause.VOID) {
                Tasks.sync(() -> p.teleport(plugin.auth().isAuthed(p) ? spawn() : authSpot()));
            }
        } else if (e.getEntity().getPersistentDataContainer().has(Keys.NPC_ID, PersistentDataType.STRING)
                || e.getEntity().getPersistentDataContainer().has(Keys.LOBBY_ENTITY, PersistentDataType.BYTE)) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOW)
    public void food(FoodLevelChangeEvent e) {
        if (isLobby(e.getEntity().getWorld())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW)
    public void brk(BlockBreakEvent e) {
        if (isLobby(e.getBlock().getWorld()) && !staffBuild(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW)
    public void place(BlockPlaceEvent e) {
        if (isLobby(e.getBlock().getWorld()) && !staffBuild(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW)
    public void drop(PlayerDropItemEvent e) {
        if (isLobby(e.getPlayer().getWorld()) && !staffBuild(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW)
    public void pickup(EntityPickupItemEvent e) {
        if (isLobby(e.getEntity().getWorld()) && !(e.getEntity() instanceof Player p && staffBuild(p))) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW)
    public void interact(PlayerInteractEvent e) {
        if (!isLobby(e.getPlayer().getWorld()) || staffBuild(e.getPlayer())) return;
        Block b = e.getClickedBlock();
        if (b != null && e.getAction() == Action.RIGHT_CLICK_BLOCK && b.getType().name().endsWith("_BUTTON")) {
            for (var en : SECRETS.entrySet()) {
                int[] c = en.getValue();
                if (b.getX() == c[0] && b.getY() == c[1] && b.getZ() == c[2]) {
                    foundSecret(e.getPlayer(), en.getKey());
                    return;
                }
            }
        }
        if (e.getAction() == Action.PHYSICAL && b != null && b.getType().name().endsWith("PRESSURE_PLATE")) return; // паркур
        // Предметы использовать в лобби нельзя (жемчуг, еда, блоки и т.д.).
        if (e.getAction() != Action.PHYSICAL) e.setCancelled(true);
    }

    public void foundSecret(Player p, String id) {
        if (plugin.profiles().unlock(p, "secret", id)) {
            plugin.profiles().addStat(p, "secrets_found", 1);
            Msg.title(p, "&d✦ Секрет найден ✦", "&7" + Msg.t("secret." + id, id), 5, 50, 15);
            Msg.sound(p, org.bukkit.Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.7f, 1.2f);
            plugin.logs().log(p, "progress", "secret", p.getLocation(), id);
        } else {
            Msg.actionBar(p, "&7Этот секрет вы уже нашли.");
        }
    }

    @EventHandler(priority = EventPriority.LOW)
    public void move(PlayerMoveEvent e) {
        if (!isLobby(e.getTo().getWorld())) return;
        if (e.getTo().getY() < 60) {
            Player p = e.getPlayer();
            e.setTo(plugin.auth().isAuthed(p) ? (parkour != null && parkour.isRunning(p) ? parkour.checkpoint(p) : spawn()) : authSpot());
        }
    }

    @EventHandler
    public void portalEnter(EntityPortalEnterEvent e) {
        if (!(e.getEntity() instanceof Player p) || !isLobby(p.getWorld())) return;
        long now = System.currentTimeMillis();
        Long last = portalCooldown.get(p.getUniqueId());
        if (last != null && now - last < 3000) return;
        portalCooldown.put(p.getUniqueId(), now);
        if (!plugin.auth().isAuthed(p)) return;
        boolean duels = p.getLocation().getZ() > 0;
        Tasks.sync(() -> {
            if (duels) {
                if (plugin.duels() != null && plugin.modules().require(p, "duels")) plugin.duels().enter(p);
            } else enterSurvival(p);
        });
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void portal(PlayerPortalEvent e) {
        if (isLobby(e.getFrom().getWorld())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void teleport(PlayerTeleportEvent e) {
        if (isLobby(e.getTo().getWorld()) && !isLobby(e.getFrom().getWorld())) {
            rememberSurvival(e.getPlayer(), e.getFrom());
        }
    }

    @EventHandler(priority = EventPriority.LOW)
    public void quit(PlayerQuitEvent e) {
        rememberSurvival(e.getPlayer(), e.getPlayer().getLocation());
        portalCooldown.remove(e.getPlayer().getUniqueId());
        entering.remove(e.getPlayer().getUniqueId());
    }

    /** Строитель лобби (один раз, версия хранится в world_state). */
    static final class LobbyBuilder {
        static void build(World w) {
            // Основная платформа (круг радиусом 18).
            for (int x = -18; x <= 18; x++) for (int z = -18; z <= 18; z++) {
                double d = Math.sqrt(x * x + z * z);
                if (d > 18.5) continue;
                Material m;
                if (d > 17.5) m = Material.POLISHED_BLACKSTONE_BRICKS;
                else if ((x == 0 || z == 0) && d > 3) m = Material.PURPUR_BLOCK;
                else if (Math.abs(d - 9) < 0.5) m = Material.AMETHYST_BLOCK;
                else if (d < 2.5) m = Material.CRYING_OBSIDIAN;
                else m = Material.POLISHED_DEEPSLATE;
                set(w, x, 100, z, m);
                set(w, x, 99, z, Material.DEEPSLATE_TILES);
                if (d > 17.5 && (x + z) % 3 == 0) set(w, x, 101, z, Material.POLISHED_BLACKSTONE_WALL);
            }
            for (int[] lp : new int[][]{{9, 9}, {-9, 9}, {9, -9}, {-9, -9}, {13, 4}, {-13, 4}, {13, -4}, {-13, -4}}) {
                set(w, lp[0], 100, lp[1], Material.SEA_LANTERN);
                set(w, lp[0], 101, lp[1], Material.POLISHED_BLACKSTONE_WALL);
                set(w, lp[0], 102, lp[1], Material.POLISHED_BLACKSTONE_WALL);
                set(w, lp[0], 103, lp[1], Material.END_ROD);
            }
            // Портал SMP (север, z = -15) и портал Дуэлей (юг, z = +15).
            portal(w, -15, Material.PURPUR_PILLAR, Material.AMETHYST_BLOCK);
            portal(w, 15, Material.RED_NETHER_BRICKS, Material.REDSTONE_LAMP);
            for (int x = -1; x <= 1; x++) for (int z = 16; z <= 18; z++) set(w, x, 100, z, Material.RED_NETHER_BRICKS);
            for (int x = -1; x <= 1; x++) for (int z = -18; z <= -16; z++) set(w, x, 100, z, Material.PURPUR_BLOCK);
            for (int z = 3; z <= 14; z++) set(w, 0, 100, z, Material.RED_NETHER_BRICKS);
            // Секрет на портале SMP (кнопка на верхней грани рамки).
            button(w, 0, 109, -15, Material.POLISHED_BLACKSTONE_BUTTON);
            // Секрет под платформой: неприметная дыра ведёт в маленькую нишу.
            set(w, 5, 100, 5, Material.AIR);
            set(w, 5, 99, 5, Material.AIR);
            set(w, 5, 95, 5, Material.AMETHYST_BLOCK);
            set(w, 5, 95, 4, Material.AMETHYST_BLOCK);
            button(w, 5, 96, 4, Material.STONE_BUTTON);
            // Паркур (по оси +X от края платформы).
            int[][] jumps = {{20, 101, 0}, {23, 101, 0}, {26, 102, 1}, {29, 103, 0}, {32, 103, -2}, {35, 104, -1}, {37, 105, 1},
                    {40, 105, 3}, {43, 106, 2}, {46, 107, 0}, {48, 108, -2}, {51, 108, -1}, {54, 109, 1}, {56, 110, 3}, {59, 111, 3}};
            for (int i = 0; i < jumps.length; i++) {
                int[] j = jumps[i];
                set(w, j[0], j[1] - 1, j[2], i == 0 || i == jumps.length - 1 ? Material.GOLD_BLOCK : i == 5 || i == 10 ? Material.IRON_BLOCK : Material.PURPUR_PILLAR);
                if (i == 0 || i == jumps.length - 1) set(w, j[0], j[1], j[2], Material.LIGHT_WEIGHTED_PRESSURE_PLATE);
                else if (i == 5 || i == 10) set(w, j[0], j[1], j[2], Material.HEAVY_WEIGHTED_PRESSURE_PLATE);
            }
            for (int x = 18; x <= 19; x++) set(w, x, 100, 0, Material.PURPUR_BLOCK);
            // Финишная площадка и секрет.
            for (int x = 59; x <= 61; x++) for (int z = 2; z <= 4; z++) if (w.getBlockAt(x, 110, z).getType().isAir()) set(w, x, 110, z, Material.AMETHYST_BLOCK);
            set(w, 60, 111, 3, Material.POLISHED_BLACKSTONE);
            button(w, 60, 112, 3, Material.POLISHED_BLACKSTONE_BUTTON);
            buildAuthRoom(w);
        }

        /** Портал с обсидиановой рамкой (ось X) и декоративной окантовкой. */
        private static void portal(World w, int z, Material deco, Material light) {
            for (int x = -4; x <= 4; x++) for (int y = 100; y <= 108; y++) {
                boolean outer = x == -4 || x == 4 || y == 108;
                boolean frame = x == -3 || x == 3 || y == 100 || y == 107;
                if (outer) set(w, x, y, z, (y == 108 && Math.abs(x) % 2 == 0) || (Math.abs(x) == 4 && y % 3 == 0) ? light : deco);
                else if (frame) set(w, x, y, z, Material.OBSIDIAN);
            }
            for (int x = -2; x <= 2; x++) for (int y = 101; y <= 106; y++) {
                Block b = w.getBlockAt(x, y, z);
                b.setType(Material.NETHER_PORTAL, false);
                if (b.getBlockData() instanceof Orientable o) {
                    o.setAxis(org.bukkit.Axis.X);
                    b.setBlockData(o, false);
                }
            }
            for (int x = -4; x <= 4; x++) for (int y = 100; y <= 108; y++) {
                Block b = w.getBlockAt(x, y, z);
                if (b.getType() == Material.REDSTONE_LAMP && b.getBlockData() instanceof org.bukkit.block.data.Lightable l) {
                    l.setLit(true);
                    b.setBlockData(l, false);
                }
            }
        }

        /** Маленькое лобби входа: уютная комната, где игрок вводит /login или /register. */
        private static void buildAuthRoom(World w) {
            int cx = 1000, cz = 1000, y0 = 149;
            for (int x = cx - 6; x <= cx + 6; x++) for (int y = y0; y <= y0 + 7; y++) for (int z = cz - 6; z <= cz + 6; z++) {
                int dx = Math.abs(x - cx), dz = Math.abs(z - cz);
                boolean wall = dx == 6 || dz == 6;
                Material m = Material.AIR;
                if (y == y0) {
                    if (dx <= 1 && dz <= 1) m = Material.CRYING_OBSIDIAN;
                    else if ((dx + dz) % 2 == 0) m = Material.POLISHED_BLACKSTONE_BRICKS;
                    else m = Material.POLISHED_DEEPSLATE;
                    if (wall) m = Material.DEEPSLATE_TILES;
                } else if (y == y0 + 7) {
                    m = (dx % 3 == 0 && dz % 3 == 0) ? Material.SEA_LANTERN : Material.DARK_OAK_PLANKS;
                } else if (wall) {
                    boolean pillar = (dx == 6 && (dz == 6 || dz == 3 || dz == 0)) || (dz == 6 && (dx == 3 || dx == 0));
                    if (pillar) m = y == y0 + 1 || y == y0 + 6 ? Material.CHISELED_POLISHED_BLACKSTONE : Material.POLISHED_BLACKSTONE_BRICKS;
                    else m = (y == y0 + 3 || y == y0 + 4) ? Material.PURPLE_STAINED_GLASS : Material.DARK_OAK_PLANKS;
                }
                set(w, x, y, z, m);
            }
            for (int[] l : new int[][]{{-3, -3}, {3, -3}, {-3, 3}, {3, 3}}) {
                set(w, cx + l[0], y0 + 6, cz + l[1], Material.IRON_CHAIN);
                Block lantern = w.getBlockAt(cx + l[0], y0 + 5, cz + l[1]);
                lantern.setType(Material.SOUL_LANTERN, false);
                if (lantern.getBlockData() instanceof org.bukkit.block.data.type.Lantern ln) {
                    ln.setHanging(true);
                    lantern.setBlockData(ln, false);
                }
            }
            for (int[] a : new int[][]{{-5, -5}, {5, -5}, {-5, 5}, {5, 5}}) {
                set(w, cx + a[0], y0 + 1, cz + a[1], Material.AMETHYST_BLOCK);
                set(w, cx + a[0], y0 + 2, cz + a[1], Material.AMETHYST_CLUSTER);
            }
        }

        private static void set(World w, int x, int y, int z, Material m) {
            w.getBlockAt(x, y, z).setType(m, false);
        }

        private static void button(World w, int x, int y, int z, Material m) {
            Block b = w.getBlockAt(x, y, z);
            b.setType(m, false);
            if (b.getBlockData() instanceof org.bukkit.block.data.FaceAttachable fa) {
                fa.setAttachedFace(org.bukkit.block.data.FaceAttachable.AttachedFace.FLOOR);
                b.setBlockData(fa, false);
            }
        }
    }
}
