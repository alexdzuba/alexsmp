package ru.unknownsmp.market;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import ru.unknownsmp.core.ChatInput;
import ru.unknownsmp.core.Module;
import ru.unknownsmp.core.Msg;
import ru.unknownsmp.core.Tasks;
import ru.unknownsmp.core.Text;
import ru.unknownsmp.core.UnknownSMP;
import ru.unknownsmp.db.Database;
import ru.unknownsmp.economy.EconomyService;
import ru.unknownsmp.gui.Items;
import ru.unknownsmp.gui.Menu;
import ru.unknownsmp.gui.PagedMenu;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Серверный магазин и скупка. Цены меняются умеренно от спроса/объёма продаж:
 * multiplier = clamp(1 + elasticity · net / baseline, min, max), где net — накопленный чистый спрос
 * (покупки минус продажи), затухающий на decay каждые interval минут. Цены всегда ≥ 1, без переполнений.
 */
public final class ShopService implements Module {
    public record ShopItem(Material material, long basePrice, double baseline, String category) {}
    public record SellItem(Material material, long basePrice, double baseline) {}
    public record Category(String id, String name, Material icon, List<ShopItem> items) {}

    private final UnknownSMP plugin;
    private final Map<String, Category> categories = new LinkedHashMap<>();
    private final Map<Material, ShopItem> shopItems = new HashMap<>();
    private final Map<Material, SellItem> sellItems = new LinkedHashMap<>();
    private final Map<String, Double> net = new ConcurrentHashMap<>();
    private final Set<String> dirty = ConcurrentHashMap.newKeySet();
    private final Set<UUID> busy = ConcurrentHashMap.newKeySet();
    private boolean dynamic;
    private double decay, elasticity, minMul, maxMul, sellCap;
    private boolean acceptAny;
    private double fbShopFraction;
    private long fbCommonStack, fbCommonSingle, fbUncommon, fbRare, fbEpic, enchantBonus;
    private final Map<String, Long> uniqueRarityPrice = new HashMap<>();
    private final java.util.Set<Material> sellBlacklist = java.util.EnumSet.noneOf(Material.class);

    public ShopService(UnknownSMP plugin) {
        this.plugin = plugin;
    }

    @Override public String id() { return "shop"; }
    @Override public String title() { return "Магазин и скупка"; }
    @Override public String[] depends() { return new String[]{"economy", "mail"}; }

    @Override
    public void enable() throws Exception {
        reload();
        plugin.db().queryBlocking(c -> {
            try (PreparedStatement ps = c.prepareStatement("SELECT item, net FROM price_state"); ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    double v = rs.getDouble(2);
                    if (Double.isFinite(v)) net.put(rs.getString(1), v);
                }
            }
            return null;
        });
        long interval = Math.max(1, plugin.configs().get("market.yml").getLong("dynamic.interval-minutes", 10)) * 60 * 20;
        Tasks.timer(interval, interval, this::decayTick);
        plugin.commands().add("shop").player().perm("usmp.player.market").module("shop").cat("Экономика")
                .usage("/shop").desc("Серверный магазин").exec((s, a) -> openShop((Player) s, null));
        plugin.commands().add("sell").player().perm("usmp.player.market").module("shop").cat("Экономика")
                .usage("/sell [hand]").desc("Скупка предметов сервером").exec((s, a) -> {
                    Player p = (Player) s;
                    if (a.length > 0 && a[0].equalsIgnoreCase("hand")) sellHand(p);
                    else openSell(p, null);
                });
    }

    @Override
    public void disable() {
        flush();
    }

    @Override
    public void reload() {
        YamlConfiguration c = plugin.configs().get("market.yml");
        dynamic = c.getBoolean("dynamic.enabled", true);
        decay = clamp(c.getDouble("dynamic.decay", 0.05), 0, 1);
        elasticity = clamp(c.getDouble("dynamic.elasticity", 0.10), 0, 1);
        minMul = clamp(c.getDouble("dynamic.min-multiplier", 0.70), 0.1, 1);
        maxMul = clamp(c.getDouble("dynamic.max-multiplier", 1.30), 1, 10);
        sellCap = clamp(c.getDouble("sell.max-fraction-of-buy", 0.8), 0.05, 1);
        acceptAny = c.getBoolean("sell.accept-any", true);
        fbShopFraction = clamp(c.getDouble("sell.fallback.shop-fraction", 0.5), 0.01, 0.8);
        fbCommonStack = Math.max(0, c.getLong("sell.fallback.common-stackable", 1));
        fbCommonSingle = Math.max(0, c.getLong("sell.fallback.common-unstackable", 3));
        fbUncommon = Math.max(0, c.getLong("sell.fallback.uncommon", 40));
        fbRare = Math.max(0, c.getLong("sell.fallback.rare", 300));
        fbEpic = Math.max(0, c.getLong("sell.fallback.epic", 1500));
        enchantBonus = Math.max(0, c.getLong("sell.enchant-bonus-per-level", 15));
        uniqueRarityPrice.clear();
        ConfigurationSection ur = c.getConfigurationSection("sell.unique-rarity-prices");
        if (ur != null) for (String k : ur.getKeys(false)) uniqueRarityPrice.put(k, Math.max(0, ur.getLong(k)));
        sellBlacklist.clear();
        for (String b : c.getStringList("sell.blacklist")) {
            Material bm = Material.matchMaterial(b);
            if (bm != null) sellBlacklist.add(bm);
        }
        categories.clear();
        shopItems.clear();
        sellItems.clear();
        ConfigurationSection cats = c.getConfigurationSection("shop.categories");
        if (cats != null) for (String id : cats.getKeys(false)) {
            ConfigurationSection cs = cats.getConfigurationSection(id);
            List<ShopItem> list = new ArrayList<>();
            ConfigurationSection items = cs.getConfigurationSection("items");
            if (items != null) for (String mat : items.getKeys(false)) {
                Material m = Material.matchMaterial(mat);
                long price = items.getLong(mat + ".buy", items.getLong(mat, 0));
                if (m == null || !m.isItem() || price <= 0) {
                    plugin.getLogger().warning("market.yml: пропущен товар " + mat);
                    continue;
                }
                ShopItem si = new ShopItem(m, price, Math.max(1, items.getDouble(mat + ".baseline", 500)), id);
                list.add(si);
                shopItems.put(m, si);
            }
            Material icon = Material.matchMaterial(cs.getString("icon", "CHEST"));
            categories.put(id, new Category(id, cs.getString("name", id), icon == null ? Material.CHEST : icon, list));
        }
        ConfigurationSection sell = c.getConfigurationSection("sell.items");
        if (sell != null) for (String mat : sell.getKeys(false)) {
            Material m = Material.matchMaterial(mat);
            long price = sell.getLong(mat + ".price", sell.getLong(mat, 0));
            if (m == null || price <= 0) {
                plugin.getLogger().warning("market.yml: пропущен предмет скупки " + mat);
                continue;
            }
            sellItems.put(m, new SellItem(m, price, Math.max(1, sell.getDouble(mat + ".baseline", 500))));
        }
    }

    private static double clamp(double v, double a, double b) {
        if (!Double.isFinite(v)) return a;
        return Math.max(a, Math.min(b, v));
    }

    private double multiplier(String key, double baseline) {
        if (!dynamic) return 1.0;
        double n = net.getOrDefault(key, 0.0);
        return clamp(1 + elasticity * n / baseline, minMul, maxMul);
    }

    public long buyPrice(Material m) {
        ShopItem si = shopItems.get(m);
        if (si == null) return -1;
        return Math.max(1, Math.round(si.basePrice() * multiplier(m.name(), si.baseline())));
    }

    public long sellPrice(Material m) {
        SellItem si = sellItems.get(m);
        if (si == null) return -1;
        long p = Math.max(1, (long) Math.floor(si.basePrice() * multiplier(m.name(), si.baseline())));
        long buy = buyPrice(m);
        if (buy > 0) p = Math.min(p, Math.max(1, (long) Math.floor(buy * sellCap)));
        return p;
    }

    /**
     * Цена скупки одной штуки конкретного предмета; -1 — сервер его не принимает.
     * Порядок: список скупки → половина цены магазина → оценка по ванильной редкости.
     * Учитываются износ (прочность) и зачарования. Уникальные предметы — по их редкости.
     */
    public long sellPrice(ItemStack it) {
        if (it == null || it.getType().isAir()) return -1;
        Material m = it.getType();
        if (sellBlacklist.contains(m) || ru.unknownsmp.gui.MenuListener.isMenuItem(it) || hasContents(it)) return -1;
        if (it.hasItemMeta() && it.getItemMeta().getPersistentDataContainer().has(ru.unknownsmp.core.Keys.of("duel_item"), org.bukkit.persistence.PersistentDataType.BYTE)) return -1;
        String type = plugin.items() == null ? null : plugin.items().typeOf(it);
        long base;
        if (type != null && type.startsWith("potion:")) {
            var pd = plugin.items().potions().get(type.substring(7));
            base = pd == null ? fallback(m) : uniqueRarityPrice.getOrDefault(pd.rarity(), 0L) / 10;
        } else if (type != null) {
            var d = plugin.items().defs().get(type);
            if (d == null || d.story() || !plugin.items().isAuthentic(it)) return -1; // сюжетные артефакты и подделки не скупаются
            base = uniqueRarityPrice.getOrDefault(d.rarity(), 0L);
        } else {
            long listed = sellPrice(m);
            if (listed > 0) base = listed;
            else if (acceptAny) base = fallback(m);
            else return -1;
        }
        if (base <= 0) return -1;
        double mul = 1.0;
        short max = m.getMaxDurability();
        if (max > 0 && it.getItemMeta() instanceof org.bukkit.inventory.meta.Damageable dm && dm.hasDamage()) {
            mul = Math.max(0.1, 1.0 - dm.getDamage() / (double) max);
        }
        long levels = 0;
        if (it.hasItemMeta()) {
            for (int lvl : it.getItemMeta().getEnchants().values()) levels += lvl;
            if (it.getItemMeta() instanceof org.bukkit.inventory.meta.EnchantmentStorageMeta es)
                for (int lvl : es.getStoredEnchants().values()) levels += lvl;
        }
        long price = (long) Math.floor(base * mul) + levels * enchantBonus;
        return Math.max(1, price);
    }

    /** Базовая цена предмета, которого нет в списке скупки. */
    private long fallback(Material m) {
        if (!m.isItem()) return -1;
        long buy = buyPrice(m);
        if (buy > 0) return Math.max(1, (long) Math.floor(buy * fbShopFraction));
        ItemStack proto = new ItemStack(m);
        long base = switch (proto.getRarity()) {
            case UNCOMMON -> fbUncommon;
            case RARE -> fbRare;
            case EPIC -> fbEpic;
            default -> proto.getMaxStackSize() > 1 ? fbCommonStack : fbCommonSingle;
        };
        if (base <= 0) return -1;
        // Динамика цены работает и для таких предметов (базовый объём 500).
        return Math.max(1, (long) Math.floor(base * multiplier(m.name(), 500)));
    }

    /** Шалкер или мешок с вещами внутри не скупается (иначе содержимое пропадёт). */
    private static boolean hasContents(ItemStack it) {
        try {
            var cont = it.getData(io.papermc.paper.datacomponent.DataComponentTypes.CONTAINER);
            if (cont != null) for (ItemStack x : cont.contents()) if (x != null && !x.isEmpty()) return true;
            var bundle = it.getData(io.papermc.paper.datacomponent.DataComponentTypes.BUNDLE_CONTENTS);
            if (bundle != null) for (ItemStack x : bundle.contents()) if (x != null && !x.isEmpty()) return true;
        } catch (Throwable ignored) {}
        return false;
    }

    public boolean acceptsAny() { return acceptAny; }

    private void record(Material m, double qty) {
        net.merge(m.name(), qty, Double::sum);
        // Ограничение накопления, чтобы значение не росло бесконечно.
        double base = shopItems.containsKey(m) ? shopItems.get(m).baseline() : sellItems.containsKey(m) ? sellItems.get(m).baseline() : 500;
        double cap = base * (maxMul - 1) / Math.max(1e-6, elasticity) * 2;
        net.computeIfPresent(m.name(), (k, v) -> clamp(v, -cap, cap));
        dirty.add(m.name());
    }

    private void decayTick() {
        for (var e : net.entrySet()) {
            double v = e.getValue() * (1 - decay);
            if (Math.abs(v) < 0.5) v = 0;
            e.setValue(v);
            dirty.add(e.getKey());
        }
        flush();
    }

    private void flush() {
        if (dirty.isEmpty()) return;
        Map<String, Double> snap = new HashMap<>();
        for (String k : dirty) snap.put(k, net.getOrDefault(k, 0.0));
        dirty.clear();
        long now = System.currentTimeMillis();
        plugin.db().tx(c -> {
            try (PreparedStatement ps = c.prepareStatement("INSERT INTO price_state(item, net, updated_at) VALUES (?,?,?) ON CONFLICT(item) DO UPDATE SET net = excluded.net, updated_at = excluded.updated_at")) {
                for (var e : snap.entrySet()) {
                    ps.setString(1, e.getKey());
                    ps.setDouble(2, e.getValue());
                    ps.setLong(3, now);
                    ps.addBatch();
                }
                ps.executeBatch();
            }
            return null;
        });
    }

    public static boolean isPlain(ItemStack it) {
        if (it == null || it.getType().isAir()) return false;
        return it.isSimilar(new ItemStack(it.getType()));
    }

    // ------------------------------------------------------------------ Покупка

    public void buy(Player p, ShopItem si, int amount, Runnable after) {
        if (amount <= 0 || amount > 64 * 36) return;
        if (!plugin.economy().tradeAllowed(p)) return;
        long each = buyPrice(si.material());
        if (each <= 0) return;
        long total;
        try { total = Math.multiplyExact(each, amount); } catch (ArithmeticException e) { return; }
        ItemStack proto = new ItemStack(si.material());
        int stacks = MailService.slotsNeeded(proto, amount);
        if (MailService.freeSlots(p) < stacks) {
            Msg.error(p, "shop.no-space", "Недостаточно места в инвентаре (нужно {n} свободных ячеек).", "n", stacks);
            return;
        }
        if (!busy.add(p.getUniqueId())) return;
        final long t = total;
        final UUID u = p.getUniqueId();
        Tasks.then(plugin.db().tx(c -> EconomyService.debit(c, u, t, "shop_buy", amount + "x" + si.material())), bal -> {
            busy.remove(u);
            plugin.economy().apply(u, bal);
            int left = amount;
            while (left > 0) {
                int a = Math.min(proto.getMaxStackSize(), left);
                ItemStack it = proto.clone();
                it.setAmount(a);
                plugin.mail().giveOrMail(p, it, "shop");
                left -= a;
            }
            p.saveData();
            record(si.material(), amount);
            Msg.ok(p, "shop.bought", "Куплено {n}x {i} за {t}.", "n", amount, "i", Items.materialName(si.material()), "t", Text.money(t));
            plugin.logs().log(p, "market", "shop_buy", p.getLocation(), amount + "x " + si.material() + " = " + t);
            if (after != null) after.run();
        }, err -> {
            busy.remove(u);
            if (err instanceof Database.TxAbort ab) Msg.error(p, ab.key, ab.def);
            else Msg.error(p, "shop.error", "Покупка не выполнена. Деньги не списаны.");
        });
    }

    // ------------------------------------------------------------------ Продажа

    /** Продать набор предметов (уже изъятых из инвентаря/меню). При ошибке предметы возвращаются. */
    public void sellItems(Player p, List<ItemStack> items, Runnable onDone) {
        long total = 0;
        Map<Material, Integer> counts = new LinkedHashMap<>();
        for (ItemStack it : items) {
            long pr = sellPrice(it);
            if (pr <= 0) continue;
            total = Math.addExact(total, Math.multiplyExact(pr, (long) it.getAmount()));
            counts.merge(it.getType(), it.getAmount(), Integer::sum);
        }
        if (total <= 0) {
            for (ItemStack it : items) plugin.mail().giveOrMail(p, it, "return");
            if (onDone != null) onDone.run();
            return;
        }
        final long t = total;
        final UUID u = p.getUniqueId();
        Tasks.then(plugin.db().tx(c -> EconomyService.credit(c, u, t, "sell", counts.toString())), bal -> {
            plugin.economy().apply(u, bal);
            for (var e : counts.entrySet()) record(e.getKey(), -e.getValue());
            // Проданные серверу уникальные предметы выводятся из оборота.
            for (ItemStack it : items) {
                String uid = plugin.items() == null ? null : plugin.items().uidOf(it);
                if (uid != null) plugin.items().setStatus(uid, "SOLD_SERVER", p.getName());
            }
            Msg.ok(p, "sell.done", "Продано на {t}.", "t", Text.money(t));
            plugin.logs().log(p, "market", "sell", p.getLocation(), counts + " = " + t);
            plugin.quests().progress(p, "EARN", "sell", t);
            for (var e : counts.entrySet()) plugin.quests().progress(p, "SELL", e.getKey().name(), e.getValue());
            p.saveData();
            if (onDone != null) onDone.run();
        }, err -> {
            for (ItemStack it : items) plugin.mail().giveOrMail(p, it, "return");
            Msg.error(p, "sell.error", "Продажа не выполнена — предметы возвращены.");
            if (onDone != null) onDone.run();
        });
    }

    private void sellHand(Player p) {
        if (!plugin.economy().tradeAllowed(p)) return;
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (sellPrice(hand) <= 0) { Msg.error(p, "sell.not-accepted", "Сервер не скупает этот предмет."); return; }
        if (!busy.add(p.getUniqueId())) return;
        ItemStack taken = hand.clone();
        p.getInventory().setItemInMainHand(null);
        sellItems(p, List.of(taken), () -> busy.remove(p.getUniqueId()));
    }

    // ------------------------------------------------------------------ Меню

    public void openShop(Player p, Menu parent) {
        new Menu(p, 4, "&8Серверный магазин") {
            @Override
            protected void build() {
                fill(Items.filler());
                int slot = 10;
                for (Category c : categories.values()) {
                    set(slot++, Items.of(c.icon()).name(c.name()).lore("&7Товаров: &f" + c.items().size(), "", "&eОткрыть").build(), cl -> openCategory(viewer, c, this));
                    if (slot == 17) slot = 19;
                    if (slot > 25) break;
                }
                set(30, Items.of(Material.HOPPER).name("&6Скупка").lore("&7Сервер принимает любые предметы", "&7(кроме шалкеров с вещами внутри и сюжетных артефактов)").build(), cl -> openSell(viewer, this));
                if (parent != null) parent(parent);
                backButton(32);
            }
        }.open();
    }

    private void openCategory(Player p, Category c, Menu parent) {
        new PagedMenu(p, "&8" + Text.strip(c.name())) {
            @Override
            protected List<Entry> entries() {
                List<Entry> out = new ArrayList<>();
                for (ShopItem si : c.items()) {
                    long price = buyPrice(si.material());
                    double mul = multiplier(si.material().name(), si.baseline());
                    String trend = mul > 1.02 ? "&c▲ спрос высокий" : mul < 0.98 ? "&a▼ цена снижена" : "&7● стабильно";
                    out.add(new Entry(Items.of(si.material()).lore("&7Цена: &6" + Text.money(price) + " &7за шт.", trend, "",
                            "&eЛКМ &7— купить 1", "&eShift+ЛКМ &7— купить стак (" + si.material().getMaxStackSize() + ")",
                            "&eПКМ &7— указать количество").build(), cl -> {
                        if (cl.right()) {
                            ChatInput.ask(viewer, Msg.t("shop.ask-amount", "&fСколько купить? (1–2304)"), s -> {
                                int n;
                                try { n = Integer.parseInt(s.trim()); } catch (NumberFormatException e) { Msg.error(viewer, "input.number", "Нужно число."); return; }
                                buy(viewer, si, n, null);
                            });
                        } else {
                            buy(viewer, si, cl.shift() ? si.material().getMaxStackSize() : 1, this::refresh);
                        }
                    }));
                }
                return out;
            }
        }.parent(parent).open();
    }

    public void openSell(Player p, Menu parent) {
        if (!plugin.economy().tradeAllowed(p)) return;
        new SellMenu(p).parent(parent).open();
    }

    private final class SellMenu extends Menu {
        private boolean done;

        SellMenu(Player p) {
            super(p, 6, "&8Скупка — положите предметы");
        }

        @Override
        protected boolean allowInput(int rawSlot) {
            return !done && rawSlot >= 0 && rawSlot < 45;
        }

        @Override
        protected void onBottomClick(org.bukkit.event.inventory.InventoryClickEvent e) {
            if (!done) e.setCancelled(false);
            onInputChange();
        }

        @Override
        protected void onInputChange() {
            Tasks.later(1, this::updateButton);
        }

        @Override
        protected void build() {
            for (int i = 45; i < 54; i++) set(i, Items.filler(Material.GRAY_STAINED_GLASS_PANE));
            updateButton();
            set(45, Items.of(Material.BOOK).name("&eЦены скупки").lore("&7Нажмите, чтобы посмотреть список").build(), c -> priceList(viewer));
            set(53, Items.of(Material.BARRIER).name("&cЗакрыть").lore("&7Предметы вернутся в инвентарь").build(), c -> viewer.closeInventory());
        }

        private void updateButton() {
            if (inv == null) return;
            long total = 0;
            int accepted = 0, rejected = 0;
            for (int i = 0; i < 45; i++) {
                ItemStack it = inv.getItem(i);
                if (it == null || it.getType().isAir()) continue;
                long pr = sellPrice(it);
                if (pr > 0) { total += pr * it.getAmount(); accepted += it.getAmount(); }
                else rejected += it.getAmount();
            }
            set(49, Items.of(Material.EMERALD).name("&a&lПродать за " + Text.money(total))
                    .lore("&7Принимается: &f" + accepted + " шт.", rejected > 0 ? "&cНе принимается: " + rejected + " шт. (вернутся)" : "",
                            "", "&eНажмите для продажи").build(), c -> sell());
        }

        private void sell() {
            if (done) return;
            if (!busy.add(viewer.getUniqueId())) return;
            List<ItemStack> toSell = new ArrayList<>();
            for (int i = 0; i < 45; i++) {
                ItemStack it = inv.getItem(i);
                if (it == null || it.getType().isAir()) continue;
                if (sellPrice(it) > 0) {
                    toSell.add(it.clone());
                    inv.setItem(i, null);
                }
            }
            if (toSell.isEmpty()) { busy.remove(viewer.getUniqueId()); Msg.error(viewer, "sell.nothing", "Нечего продавать."); return; }
            lock();
            sellItems(viewer, toSell, () -> {
                busy.remove(viewer.getUniqueId());
                unlock();
                if (viewer.getOpenInventory().getTopInventory() == inv) updateButton();
            });
        }

        @Override
        protected void onClose() {
            done = true;
            for (int i = 0; i < 45; i++) {
                ItemStack it = inv.getItem(i);
                if (it == null || it.getType().isAir()) continue;
                inv.setItem(i, null);
                var left = viewer.getInventory().addItem(it);
                for (ItemStack l : left.values()) viewer.getWorld().dropItemNaturally(viewer.getLocation(), l);
            }
            viewer.saveData();
        }
    }

    private void priceList(Player p) {
        new PagedMenu(p, "&8Цены скупки") {
            @Override
            protected List<Entry> entries() {
                List<Entry> out = new ArrayList<>();
                if (acceptAny) out.add(new Entry(Items.of(Material.KNOWLEDGE_BOOK).name("&eЛюбые другие предметы")
                        .lore("&7Принимаются по базовой цене:", "&7есть в магазине — половина цены магазина,", "&7иначе — по редкости предмета.",
                                "&7Износ снижает цену, зачарования повышают.").build(), null));
                for (SellItem si : sellItems.values()) {
                    if (!si.material().isItem()) continue;
                    out.add(new Entry(Items.of(si.material()).lore("&7Скупка: &6" + Text.money(sellPrice(si.material())) + " &7за шт.").build(), null));
                }
                return out;
            }
        }.open();
    }

    public Map<Material, SellItem> sellList() { return sellItems; }

    public Map<String, Category> categories() { return categories; }
}
