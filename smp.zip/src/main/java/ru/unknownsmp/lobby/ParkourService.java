package ru.unknownsmp.lobby;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import ru.unknownsmp.core.Msg;
import ru.unknownsmp.core.Tasks;
import ru.unknownsmp.core.UnknownSMP;
import ru.unknownsmp.db.Database;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Паркур лобби: старт (золотая плита), чекпоинты (железные), финиш. Лучшее время сохраняется. */
public final class ParkourService implements Listener {
    private static final String COURSE = "lobby";
    private final UnknownSMP plugin;
    private final LobbyService lobby;
    private final Map<UUID, Run> runs = new ConcurrentHashMap<>();
    private final Map<UUID, Boolean> teleporting = new ConcurrentHashMap<>();

    private static final class Run {
        long start;
        Location checkpoint;
        Location startLoc;
    }

    ParkourService(UnknownSMP plugin, LobbyService lobby) {
        this.plugin = plugin;
        this.lobby = lobby;
        Tasks.timer(5, 5, () -> {
            for (var e : runs.entrySet()) {
                Player p = plugin.getServer().getPlayer(e.getKey());
                if (p == null) continue;
                Msg.actionBar(p, "&eПаркур: &f" + fmt(System.currentTimeMillis() - e.getValue().start));
            }
        });
    }

    public boolean isRunning(Player p) { return runs.containsKey(p.getUniqueId()); }

    public Location checkpoint(Player p) {
        Run r = runs.get(p.getUniqueId());
        return r == null ? lobby.spawn() : r.checkpoint.clone();
    }

    @EventHandler
    public void plate(PlayerInteractEvent e) {
        if (e.getAction() != Action.PHYSICAL) return;
        Block b = e.getClickedBlock();
        if (b == null || !lobby.isLobby(b.getWorld())) return;
        Player p = e.getPlayer();
        if (b.getType() == Material.LIGHT_WEIGHTED_PRESSURE_PLATE) {
            Run r = runs.get(p.getUniqueId());
            boolean isStart = b.getX() < 30;
            if (isStart) {
                if (r != null && System.currentTimeMillis() - r.start < 1500) return;
                Run nr = new Run();
                nr.start = System.currentTimeMillis();
                nr.checkpoint = b.getLocation().add(0.5, 0.1, 0.5);
                nr.checkpoint.setYaw(-90);
                nr.startLoc = nr.checkpoint.clone();
                runs.put(p.getUniqueId(), nr);
                Msg.actionBar(p, "&aСтарт! Не падайте.");
                Msg.sound(p, Sound.BLOCK_NOTE_BLOCK_PLING, 0.6f, 1.5f);
            } else if (r != null) {
                finish(p, r);
            }
        } else if (b.getType() == Material.HEAVY_WEIGHTED_PRESSURE_PLATE) {
            Run r = runs.get(p.getUniqueId());
            if (r == null) return;
            Location cp = b.getLocation().add(0.5, 0.1, 0.5);
            cp.setYaw(-90);
            if (r.checkpoint.getBlockX() != cp.getBlockX()) {
                r.checkpoint = cp;
                Msg.actionBar(p, "&bЧекпоинт сохранён");
                Msg.sound(p, Sound.BLOCK_NOTE_BLOCK_BELL, 0.6f, 1.6f);
            }
        }
    }

    private void finish(Player p, Run r) {
        runs.remove(p.getUniqueId());
        long time = System.currentTimeMillis() - r.start;
        if (time < 8000) {
            // Нереально быстрое прохождение — не засчитываем.
            plugin.logs().suspicious(p, "parkour_time", fmt(time));
            Msg.error(p, "parkour.invalid", "Результат не засчитан.");
            return;
        }
        Msg.title(p, "&a&lФИНИШ!", "&f" + fmt(time), 5, 50, 15);
        Msg.sound(p, Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.7f, 1.3f);
        boolean first = plugin.profiles().get(p) != null && plugin.profiles().get(p).stat("parkour_done") == 0;
        plugin.profiles().addStat(p, "parkour_done", 1);
        final String u = p.getUniqueId().toString();
        Tasks.then(plugin.db().tx(c -> {
            Long best = Database.longVal(c, "SELECT best_ms FROM parkour WHERE uuid=? AND course=?", u, COURSE);
            if (best == null) Database.update(c, "INSERT INTO parkour(uuid, course, best_ms) VALUES (?,?,?)", u, COURSE, time);
            else if (time < best) Database.update(c, "UPDATE parkour SET best_ms=? WHERE uuid=? AND course=?", time, u, COURSE);
            return best;
        }), best -> {
            if (best == null || time < best) Msg.ok(p, "parkour.record", "Новый личный рекорд: {t}", "t", fmt(time));
            else Msg.send(p, "parkour.result", "&7Время: &f{t}&7. Рекорд: &f{b}", "t", fmt(time), "b", fmt(best));
        }, null);
        if (first) {
            long reward = plugin.configs().main().getLong("lobby.parkour-first-reward", 500);
            if (reward > 0) plugin.economy().deposit(p.getUniqueId(), reward, "parkour_first", null);
        }
        Tasks.later(40, () -> { if (p.isOnline() && lobby.isLobby(p.getWorld())) p.teleport(lobby.spawn()); });
    }

    @EventHandler
    public void tp(PlayerTeleportEvent e) {
        if (e.getCause() == PlayerTeleportEvent.TeleportCause.PLUGIN && runs.containsKey(e.getPlayer().getUniqueId())
                && !lobby.isLobby(e.getTo().getWorld())) {
            runs.remove(e.getPlayer().getUniqueId());
        }
        if (e.getCause() == PlayerTeleportEvent.TeleportCause.ENDER_PEARL || e.getCause() == PlayerTeleportEvent.TeleportCause.COMMAND) {
            runs.remove(e.getPlayer().getUniqueId());
        }
    }

    @EventHandler
    public void quit(PlayerQuitEvent e) {
        runs.remove(e.getPlayer().getUniqueId());
        teleporting.remove(e.getPlayer().getUniqueId());
    }

    public static String fmt(long ms) {
        return String.format("%d:%02d.%03d", ms / 60000, (ms / 1000) % 60, ms % 1000);
    }
}
