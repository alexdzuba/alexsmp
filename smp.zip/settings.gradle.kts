rootProject.name = "UnknownSMP"
