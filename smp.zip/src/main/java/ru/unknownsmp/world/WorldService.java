package ru.unknownsmp.world;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldBorder;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.hanging.HangingBreakByEntityEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import ru.unknownsmp.core.Module;
import ru.unknownsmp.core.Msg;
import ru.unknownsmp.core.Text;
import ru.unknownsmp.core.UnknownSMP;

/** Основной мир: граница, общий спавн и его безопасная зона. Приватов игроков нет. */
public final class WorldService implements Module, Listener {
    private final UnknownSMP plugin;
    private int radius;
    private boolean blockMonsters;

    public WorldService(UnknownSMP plugin) {
        this.plugin = plugin;
    }

    @Override public String id() { return "world"; }
    @Override public String title() { return "Мир и спавн"; }

    @Override
    public String[] depends() { return new String[]{"state"}; }

    @Override
    public void enable() {
        reload();
        Bukkit.getPluginManager().registerEvents(this, plugin);
        applyBorder();
        if (plugin.configs().main().getBoolean("survival.build-spawn", true) && plugin.state().getLong("smp_spawn_built", 0) < 1) {
            World w = plugin.survivalWorld();
            Location base = w.getSpawnLocation();
            plugin.getLogger().info("Строю площадь спавна SMP в " + base.getBlockX() + ", " + base.getBlockZ() + "...");
            Location sp = SpawnBuilder.build(w, base.getBlockX(), base.getBlockZ());
            setSpawn(sp);
            plugin.state().set("smp_spawn_built", 1);
            plugin.getLogger().info("Спавн SMP построен: " + Text.coords(sp));
        }
        spawnHologram();
    }

    private void spawnHologram() {
        Location s = spawn();
        if (s.getWorld() == null) return;
        for (org.bukkit.entity.Entity e : s.getWorld().getNearbyEntities(s, 12, 12, 12)) {
            if (e.getPersistentDataContainer().has(ru.unknownsmp.core.Keys.HOLOGRAM, org.bukkit.persistence.PersistentDataType.STRING)) e.remove();
        }
        Location h = s.clone().add(0, 3.2, -3.5);
        s.getWorld().spawn(h, org.bukkit.entity.TextDisplay.class, td -> {
            td.text(Text.c(plugin.configs().main().getString("survival.spawn-hologram",
                    "&5&lUNKNOWN SMP\n&7Зона спавна безопасна: PvP и разрушение запрещены\n&7За её пределами — всё по-настоящему\n&e/menu &7— меню  &e/help &7— команды")));
            td.setBillboard(org.bukkit.entity.Display.Billboard.CENTER);
            td.setBackgroundColor(org.bukkit.Color.fromARGB(110, 10, 0, 20));
            td.setPersistent(false);
            td.getPersistentDataContainer().set(ru.unknownsmp.core.Keys.HOLOGRAM, org.bukkit.persistence.PersistentDataType.STRING, "spawn");
        });
    }

    @Override
    public void reload() {
        YamlConfiguration c = plugin.configs().main();
        radius = c.getInt("spawn-zone.radius", 48);
        blockMonsters = c.getBoolean("spawn-zone.block-monsters", true);
    }

    public void applyBorder() {
        YamlConfiguration c = plugin.configs().main();
        if (!c.getBoolean("border.enabled", true)) return;
        double size = c.getDouble("border.size", 20000);
        double cx = c.getDouble("border.center-x", 0), cz = c.getDouble("border.center-z", 0);
        World w = plugin.survivalWorld();
        setBorder(w, cx, cz, size);
        for (World other : Bukkit.getWorlds()) {
            if (other == w || other.getName().equals(plugin.lobbyWorldName())) continue;
            if (other.getEnvironment() == World.Environment.NETHER && c.getBoolean("border.nether-scaled", true)) {
                setBorder(other, cx / 8, cz / 8, size / 8);
            } else if (other.getEnvironment() == World.Environment.THE_END) {
                setBorder(other, 0, 0, size);
            }
        }
    }

    private void setBorder(World w, double x, double z, double size) {
        WorldBorder b = w.getWorldBorder();
        b.setCenter(x, z);
        b.setSize(size);
        b.setWarningDistance(16);
    }

    public Location spawn() {
        Location l = Text.loc(plugin.configs().main().getString("survival.spawn", ""));
        if (l != null) return l;
        World w = plugin.survivalWorld();
        Location s = w.getSpawnLocation();
        return s.add(0.5, 0, 0.5);
    }

    public void setSpawn(Location l) {
        plugin.configs().main().set("survival.spawn", Text.loc(l));
        plugin.configs().save("config.yml");
        l.getWorld().setSpawnLocation(l);
    }

    public int radius() { return radius; }

    public boolean inSpawnZone(Location l) {
        if (l == null || l.getWorld() == null) return false;
        Location s = spawn();
        if (s.getWorld() == null || !s.getWorld().equals(l.getWorld())) return false;
        double dx = l.getX() - s.getX(), dz = l.getZ() - s.getZ();
        return dx * dx + dz * dz <= (double) radius * radius;
    }

    private boolean bypass(Player p) {
        return plugin.roles().has(p, "usmp.admin.build");
    }

    // ---------- Защита зоны спавна ----------

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void brk(BlockBreakEvent e) {
        if (inSpawnZone(e.getBlock().getLocation()) && !bypass(e.getPlayer())) {
            e.setCancelled(true);
            Msg.actionBar(e.getPlayer(), Msg.t("spawn.protected", "&cЗона спавна защищена"));
        }
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void place(BlockPlaceEvent e) {
        if (inSpawnZone(e.getBlock().getLocation()) && !bypass(e.getPlayer())) {
            e.setCancelled(true);
            Msg.actionBar(e.getPlayer(), Msg.t("spawn.protected", "&cЗона спавна защищена"));
        }
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void bucket(PlayerBucketEmptyEvent e) {
        if (inSpawnZone(e.getBlock().getLocation()) && !bypass(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW)
    public void interact(PlayerInteractEvent e) {
        if (e.getClickedBlock() == null) return;
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK && e.getAction() != Action.PHYSICAL && e.getAction() != Action.LEFT_CLICK_BLOCK) return;
        if (!inSpawnZone(e.getClickedBlock().getLocation()) || bypass(e.getPlayer())) return;
        // Взаимодействие с NPC-блоками лобби и меню разрешено через сущности; блоки зоны — запрещены.
        e.setUseInteractedBlock(org.bukkit.event.Event.Result.DENY);
        if (e.getAction() == Action.RIGHT_CLICK_BLOCK && e.getItem() != null && e.getItem().getType().isBlock()) {
            e.setUseItemInHand(org.bukkit.event.Event.Result.DENY);
        }
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void interactEntity(PlayerInteractEntityEvent e) {
        if (e.getRightClicked() instanceof org.bukkit.entity.ItemFrame && inSpawnZone(e.getRightClicked().getLocation()) && !bypass(e.getPlayer())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void hanging(HangingBreakByEntityEvent e) {
        if (inSpawnZone(e.getEntity().getLocation()) && !(e.getRemover() instanceof Player p && bypass(p))) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void explode(EntityExplodeEvent e) {
        e.blockList().removeIf(b -> inSpawnZone(b.getLocation()));
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void explodeBlock(BlockExplodeEvent e) {
        e.blockList().removeIf(b -> inSpawnZone(b.getLocation()));
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void flow(BlockFromToEvent e) {
        if (inSpawnZone(e.getToBlock().getLocation()) && !inSpawnZone(e.getBlock().getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void piston(BlockPistonExtendEvent e) {
        for (Block b : e.getBlocks()) {
            if (inSpawnZone(b.getRelative(e.getDirection()).getLocation()) && !inSpawnZone(e.getBlock().getLocation())) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void burn(BlockBurnEvent e) {
        if (inSpawnZone(e.getBlock().getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void ignite(BlockIgniteEvent e) {
        if (inSpawnZone(e.getBlock().getLocation()) && !(e.getPlayer() != null && bypass(e.getPlayer()))) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void changeBlock(EntityChangeBlockEvent e) {
        if (!(e.getEntity() instanceof Player) && inSpawnZone(e.getBlock().getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void spawnMob(CreatureSpawnEvent e) {
        if (!blockMonsters || !(e.getEntity() instanceof Monster)) return;
        if (e.getSpawnReason() == CreatureSpawnEvent.SpawnReason.CUSTOM || e.getSpawnReason() == CreatureSpawnEvent.SpawnReason.COMMAND) return;
        if (inSpawnZone(e.getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void respawn(PlayerRespawnEvent e) {
        if (!e.isBedSpawn() && !e.isAnchorSpawn()) {
            e.setRespawnLocation(spawn());
        }
    }
}
