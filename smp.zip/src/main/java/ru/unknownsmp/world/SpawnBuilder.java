package ru.unknownsmp.world;

import org.bukkit.HeightMap;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.Bisected;
import org.bukkit.block.data.type.Lantern;
import org.bukkit.block.data.type.Slab;
import org.bukkit.block.data.type.Stairs;

/**
 * Строит площадь общего спавна SMP: древняя каменная площадь с фонтаном, фонарями,
 * клумбами и арками на четырёх выходах. Выполняется один раз (версия хранится в world_state).
 */
public final class SpawnBuilder {
    private SpawnBuilder() {}

    public static final int R = 22;

    /** @return точка появления игроков. */
    public static Location build(World w, int cx, int cz) {
        // Средняя высота настоящей земли (без деревьев и растений) в области площади.
        int sum = 0, n = 0;
        for (int dx = -R; dx <= R; dx += 4) for (int dz = -R; dz <= R; dz += 4) {
            if (dx * dx + dz * dz > R * R) continue;
            sum += groundY(w, cx + dx, cz + dz);
            n++;
        }
        int y = n == 0 ? groundY(w, cx, cz) : Math.round(sum / (float) n);
        if (y < w.getSeaLevel()) y = w.getSeaLevel();
        if (y > 140) y = 140;
        // Площадь и фундамент.
        for (int dx = -R - 4; dx <= R + 4; dx++) for (int dz = -R - 4; dz <= R + 4; dz++) {
            double d = Math.sqrt(dx * dx + dz * dz);
            int x = cx + dx, z = cz + dz;
            if (d <= R + 0.5) {
                for (int yy = y - 1; yy >= y - 12; yy--) {
                    Block b = w.getBlockAt(x, yy, z);
                    if (replaceable(b.getType())) b.setType(yy == y - 1 ? Material.STONE_BRICKS : Material.STONE, false);
                    else break;
                }
                for (int yy = y + 1; yy <= y + 24; yy++) {
                    Block b = w.getBlockAt(x, yy, z);
                    if (!b.getType().isAir()) b.setType(Material.AIR, false);
                }
                w.getBlockAt(x, y, z).setType(floor(dx, dz, d), false);
            } else if (d <= R + 4) {
                // Мягкий переход: убираем деревья над краем и засыпаем ямы.
                for (int yy = y + 1; yy <= y + 24; yy++) {
                    Block b = w.getBlockAt(x, yy, z);
                    Material m = b.getType();
                    if (m.name().endsWith("_LEAVES") || m.name().endsWith("_LOG") || m == Material.VINE) b.setType(Material.AIR, false);
                }
                Block top = w.getBlockAt(x, y, z);
                if (replaceable(top.getType())) top.setType(Material.GRASS_BLOCK, false);
                for (int yy = y - 1; yy >= y - 6; yy--) {
                    Block b = w.getBlockAt(x, yy, z);
                    if (replaceable(b.getType())) b.setType(Material.DIRT, false);
                    else break;
                }
            }
        }
        // Низкая ограда по краю с проходами по осям.
        for (int a = 0; a < 360; a += 2) {
            double rad = Math.toRadians(a);
            int dx = (int) Math.round(Math.cos(rad) * R), dz = (int) Math.round(Math.sin(rad) * R);
            if (Math.abs(dx) <= 2 || Math.abs(dz) <= 2) continue;
            w.getBlockAt(cx + dx, y + 1, cz + dz).setType(Material.MOSSY_STONE_BRICK_WALL, true);
        }
        fountain(w, cx, y, cz);
        // Фонари.
        for (int k = 0; k < 8; k++) {
            double rad = Math.toRadians(22.5 + 45 * k);
            int x = cx + (int) Math.round(Math.cos(rad) * 12), z = cz + (int) Math.round(Math.sin(rad) * 12);
            lampPost(w, x, y, z);
        }
        for (int k = 0; k < 8; k++) {
            double rad = Math.toRadians(45 * k + 22.5);
            int x = cx + (int) Math.round(Math.cos(rad) * 19), z = cz + (int) Math.round(Math.sin(rad) * 19);
            lampPost(w, x, y, z);
        }
        // Клумбы между дорожками.
        for (int k = 0; k < 4; k++) {
            double rad = Math.toRadians(45 + 90 * k);
            int x = cx + (int) Math.round(Math.cos(rad) * 16), z = cz + (int) Math.round(Math.sin(rad) * 16);
            planter(w, x, y, z);
        }
        // Арки на выходах.
        arch(w, cx, y, cz - R, true);
        arch(w, cx, y, cz + R, true);
        arch(w, cx - R, y, cz, false);
        arch(w, cx + R, y, cz, false);
        // Скамейки у фонтана.
        bench(w, cx + 6, y, cz, BlockFace.WEST);
        bench(w, cx - 6, y, cz, BlockFace.EAST);
        Location spawn = new Location(w, cx + 0.5, y + 1, cz + 7.5, 180, 0);
        return spawn;
    }

    /** Верхний блок земли: пропускаем воздух, листву, стволы и растения. */
    static int groundY(World w, int x, int z) {
        int y = w.getHighestBlockYAt(x, z, HeightMap.MOTION_BLOCKING_NO_LEAVES);
        while (y > w.getMinHeight() + 1) {
            Material m = w.getBlockAt(x, y, z).getType();
            if (m.isAir() || replaceable(m) || m.name().endsWith("_LOG") || m.name().endsWith("_WOOD") || m == Material.MUSHROOM_STEM
                    || m == Material.BROWN_MUSHROOM_BLOCK || m == Material.RED_MUSHROOM_BLOCK || m == Material.BAMBOO) {
                y--;
                continue;
            }
            break;
        }
        return y;
    }

    private static boolean replaceable(Material m) {
        return m.isAir() || m == Material.WATER || m == Material.LAVA || m == Material.SHORT_GRASS || m == Material.TALL_GRASS
                || m == Material.FERN || m == Material.LARGE_FERN || m == Material.SNOW || m.name().endsWith("_LEAVES")
                || m.name().endsWith("_FLOWER") || m == Material.DANDELION || m == Material.POPPY || m == Material.SEAGRASS
                || m == Material.TALL_SEAGRASS || m == Material.KELP || m == Material.KELP_PLANT || m == Material.DEAD_BUSH
                || m == Material.SWEET_BERRY_BUSH || m == Material.VINE;
    }

    private static Material floor(int dx, int dz, double d) {
        if (d < 3.5) return Material.CHISELED_STONE_BRICKS;
        if (Math.abs(d - 5) < 0.6) return Material.POLISHED_ANDESITE;
        if (Math.abs(d - (R - 1)) < 0.6) return Material.POLISHED_DEEPSLATE;
        if (Math.abs(dx) <= 1 || Math.abs(dz) <= 1) return Material.STONE_BRICKS;
        if (Math.abs(d - 10) < 0.5) return Material.POLISHED_ANDESITE;
        int h = Math.floorMod(dx * 73856093 ^ dz * 19349663, 10);
        return switch (h) {
            case 0, 1 -> Material.MOSSY_STONE_BRICKS;
            case 2 -> Material.CRACKED_STONE_BRICKS;
            case 3 -> Material.ANDESITE;
            case 4 -> Material.MOSS_BLOCK;
            default -> Material.STONE_BRICKS;
        };
    }

    private static void fountain(World w, int cx, int y, int cz) {
        for (int dx = -4; dx <= 4; dx++) for (int dz = -4; dz <= 4; dz++) {
            double d = Math.sqrt(dx * dx + dz * dz);
            int x = cx + dx, z = cz + dz;
            if (d < 3.0) {
                w.getBlockAt(x, y - 1, z).setType(Material.STONE_BRICKS, false);
                w.getBlockAt(x, y, z).setType(Material.WATER, false);
            } else if (d < 4.0) {
                w.getBlockAt(x, y + 1, z).setType(Material.STONE_BRICK_WALL, true);
                w.getBlockAt(x, y, z).setType(Material.CHISELED_STONE_BRICKS, false);
            }
        }
        // Центральная колонна.
        w.getBlockAt(cx, y, cz).setType(Material.CHISELED_STONE_BRICKS, false);
        for (int yy = y + 1; yy <= y + 4; yy++) w.getBlockAt(cx, yy, cz).setType(yy == y + 4 ? Material.CHISELED_QUARTZ_BLOCK : Material.QUARTZ_PILLAR, false);
        w.getBlockAt(cx, y + 5, cz).setType(Material.SEA_LANTERN, false);
        w.getBlockAt(cx, y + 6, cz).setType(Material.AMETHYST_CLUSTER, false);
        for (BlockFace f : new BlockFace[]{BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST}) {
            Block b = w.getBlockAt(cx + f.getModX(), y + 4, cz + f.getModZ());
            b.setType(Material.LANTERN, false);
        }
    }

    private static void lampPost(World w, int x, int y, int z) {
        w.getBlockAt(x, y, z).setType(Material.POLISHED_ANDESITE, false);
        for (int yy = y + 1; yy <= y + 3; yy++) w.getBlockAt(x, yy, z).setType(Material.STONE_BRICK_WALL, true);
        Block l = w.getBlockAt(x, y + 4, z);
        l.setType(Material.LANTERN, false);
        if (l.getBlockData() instanceof Lantern ln) { ln.setHanging(false); l.setBlockData(ln, false); }
    }

    private static void planter(World w, int x, int y, int z) {
        for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) {
            w.getBlockAt(x + dx, y, z + dz).setType(Material.MOSS_BLOCK, false);
            boolean edge = Math.abs(dx) == 1 || Math.abs(dz) == 1;
            Material flower = (dx + dz) % 2 == 0 ? Material.AZURE_BLUET : Material.CORNFLOWER;
            w.getBlockAt(x + dx, y + 1, z + dz).setType(edge ? flower : Material.FLOWERING_AZALEA, false);
        }
    }

    private static void arch(World w, int x, int y, int z, boolean alongX) {
        for (int side : new int[]{-3, 3}) {
            int px = alongX ? x + side : x, pz = alongX ? z : z + side;
            for (int yy = y + 1; yy <= y + 5; yy++)
                w.getBlockAt(px, yy, pz).setType(yy == y + 1 || yy == y + 5 ? Material.CHISELED_STONE_BRICKS : Material.STONE_BRICKS, false);
            Block lan = w.getBlockAt(px, y + 6, pz);
            lan.setType(Material.LANTERN, false);
        }
        for (int o = -3; o <= 3; o++) {
            int bx = alongX ? x + o : x, bz = alongX ? z : z + o;
            Block b = w.getBlockAt(bx, y + 5, bz);
            if (Math.abs(o) < 3) {
                b.setType(Material.STONE_BRICK_SLAB, false);
                if (b.getBlockData() instanceof Slab s) { s.setType(Slab.Type.TOP); b.setBlockData(s, false); }
            }
        }
        Block mid = w.getBlockAt(x, y + 6, z);
        mid.setType(Material.CHISELED_STONE_BRICKS, false);
    }

    private static void bench(World w, int x, int y, int z, BlockFace facing) {
        for (int o = -1; o <= 1; o++) {
            int bx = facing == BlockFace.WEST || facing == BlockFace.EAST ? x : x + o;
            int bz = facing == BlockFace.WEST || facing == BlockFace.EAST ? z + o : z;
            if (Math.abs(bz - z) == 0 && Math.abs(bx - x) == 0 && o != 0) continue;
            Block b = w.getBlockAt(bx, y + 1, bz);
            b.setType(Material.SPRUCE_STAIRS, false);
            if (b.getBlockData() instanceof Stairs s) {
                s.setFacing(facing.getOppositeFace());
                s.setHalf(Bisected.Half.BOTTOM);
                b.setBlockData(s, false);
            }
        }
    }
}
